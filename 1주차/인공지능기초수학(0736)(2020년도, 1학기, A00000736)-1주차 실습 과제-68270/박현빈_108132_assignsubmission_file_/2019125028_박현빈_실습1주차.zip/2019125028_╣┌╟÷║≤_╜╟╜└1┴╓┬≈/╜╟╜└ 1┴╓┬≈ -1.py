import numpy as np

a = np.ones(5)
print("1 - a)", a)
b = np.zeros(5)
print("1 - b)", b)
c = np.full(5, 5, dtype = np.int32)
print("1 - c)", c)
d = np.arange(1,6,1)
print("1 - d)", d)
e = np.arange(1,10,2)
print("1 - e)", e)
f = np.array([1, 5, 2, 3, 9])
print("1 - f)", f)


